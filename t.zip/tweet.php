﻿<?php
include('lib.php');
if(!isset($_SESSION['access_token'])){
   header('Location:index.php');
}
if(!isset($_POST['tw'])){ 
echo <<<EOT
<html>
 <body>
  <form action='tweet.php' method='post'>
   <textarea name='tw'></textarea><br/>
   <input type='submit' value='发一条微博！'/>
  </form>
 </body>
</html>
EOT;
exit;
}
$access_token=$_SESSION['access_token'];
$content=$_POST['tw'];
$result=tweet($content);
$result=json_decode($result,true);
if($result['errcode']==0)echo '发表成功！<a href=index.php>返回</a>';


?>