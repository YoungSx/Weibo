﻿<?php
include('lib.php');
$access_token=$_SESSION['access_token'];
if(!isset($_SESSION['access_token'])) exit;
echo "
<html>
 <head>
  <link href=\"Style/style.css\" rel='stylesheet' type='text/css'/>
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes\">
  <title>Ysx Home</title>
  <script type=\"text/javascript\" src=\"/t/Js/script.js\">
  </script>
 </head>
 <body><div id='title'><a href=home.php>Ysx Home</a></div>
";
$updata=updata(6,1);
if($updata){
   $updata=$updata['data'];
   $new_fans_num=$updata['mentions'];
}
   echo "<div id=\"new_fans_num\">新[$new_fans_num]</div><br />";
if(isset($_GET['page'])) $at=at_list($_GET['page']);
else $at=at_list(0);
echo $at;
echo "<div class=fanye><a href=at.php?page=-1>&lt;</a> 翻页 <a href=at.php?page=1>&gt;</a></div></body></html>";
?>