﻿<?php
echo <<<EOT
<!DOCTYPE html>
<html>
 <head>
  <link href="Style/style.css" rel='stylesheet' type='text/css'/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=2.0, user-scalable=no"/>
  <title>Ysx版微博</title>
  <script type="text/javascript" src="/Js/script.js">
  </script>
 </head>
 <body onload="yc('tips')">
  <div id="main">
  <div id='title'><a href=home.php>Ysx版微博</a></div>
EOT;


require('lib.php');
if(!isset($_SESSION['access_token'])){
   if(isset($_COOKIE['user'])){
	  $cookie=$_COOKIE['user'];
	  $cookie=explode("|",$cookie);
	  $access_token=iconv('ASCII','UTF-8',$cookie[0]);
	  $refresh_token=iconv('ASCII','UTF-8',$cookie[1]);
	  $openid=iconv('ASCII','UTF-8',$cookie[2]);
	  if(!$access_token || !$refresh_token || !$openid){
	     unset($_COOKIE['user']);
		 toauth();
	  }
	  refresh_token($access_token,$refresh_token);
	  
	  $access_token=$_SESSION['access_token'];
	  $refresh_token=$_SESSION['refresh_token'];
	  $_SESSION['openid']=$openid;
	  setcookie('user',$access_token.'|'.$refresh_token.'|'.$openid,time()+60*60*24*7);
	  
   }else{
      toauth();
   }
}
function toauth(){
   global $appid,$callback;
   $url='https://open.t.qq.com/cgi-bin/oauth2/authorize';
   $cs = array('response_type'=>'code','client_id'=> $appid , 'redirect_uri' => $callback );
   foreach( $cs as $key => $val){
      $a[]=$key.'='.urlencode($val);
   }
   $cans.=join('&',$a);
   header('Location: '.$url.'?'.$cans);
}
$access_token=$_SESSION['access_token'];
$tips='';
///////////////////////////
if(isset($_POST['tw'])){
   $content=$_POST['tw'];
   if($_POST['longitude']&&$_POST['latitude']) $result=tweet($content,$_POST['longitude'],$_POST['latitude']);
   else $result=tweet($content);
   $result=json_decode($result,true);
   if($result['errcode']==0)$tips= '发表成功！';
}
///////////////////////////////// 转播、评论
if(isset($_POST['zpcont']) && isset($_POST['id'])){
   if(retweet($_POST['zpcont'],$_POST['id'],$_POST['cz']))$tips='操作成功';
   else $tips='操作失败';
}
///////////////////////////////// +1
if(isset($_GET['like']) && $_GET['like']){
   if(retweet('+1',$_GET['like'],0))$tips='操作成功';
   else $tips='操作失败';
}
///////////////////////////////// 翻页
if(isset($_GET['page'])) $timeline=tl_list($_GET['page']);
else $timeline=tl_list(0);
/////////////////////////////////
if($tips!='')$tips="<div id='tips'>".$tips.'</div>';
$a=info();
$fansnum=$a['fansnum'];
$idolnum=$a['idolnum'];
$new_fans_num='';
$new_at_num='';
$updata=updata();
if($updata){
   $updata=$updata['data'];
   if($updata['fans']!=0)$new_fans_num='['.$updata['fans'].']';
   if($updata['mentions']!=0)$new_at_num='['.$updata['mentions'].']';
}

echo <<<AAA

  $tips
  <div id='head'>
  $_SESSION[nick](@$_SESSION[name])<br />
  <a href='fans.php?type=0&page=0'>听众:$fansnum$new_fans_num</a> <a href='fans.php?type=1&page=0'>收听:$idolnum</a> <a href='at.php?page=0'>@提到我的$new_at_num</a>
  <form action='home.php' method='post'>
   <textarea name='tw'></textarea><div class="bar">
   <input type="button" onclick="navigator.geolocation.getCurrentPosition(info,cuowu);" id='local' value="定位"/>
   <input type="hidden" value="" id="latitude" name="latitude"/><input value="" type="hidden" id="longitude" name="longitude"/>
   <input type="submit" value="发微博！"/></div>
  </form>
  </div>
  <div id='timeline'>
  $timeline
  <div class=foot><a href=home.php?page=-1>&lt;</a> 翻页 <a href=home.php?page=1>&gt;</a></div>
  </div>
  </div>
  </body>
</html>
AAA;

?>