﻿<?php
include('cfg.php');
session_start();
function request($url){
   $ch = curl_init(); 
   curl_setopt($ch, CURLOPT_URL,$url); 
   curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
   curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); 
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
   
   curl_setopt($ch, CURLOPT_POST, 1);
   curl_setopt($ch, CURLOPT_POSTFIELDS, $url);
   return curl_exec($ch); 
}
function param($para){
   global $appid,$access_token;
   $openid=$_SESSION['openid'];
   $cans=array(
      'oauth_consumer_key'=>$appid,
	  'access_token'=>$access_token,
	  'openid'=>$openid,
	  'clientip'=>$_SERVER["REMOTE_ADDR"],
	  'oauth_version'=>'2.a',
	  'scope'=>'all'
   );
   if(is_array($para)) $cans = array_merge($cans,$para);//新旧参数数组合并
   ksort($cans);//参数数组排序
   foreach($cans as $key=>$val){
      $a[].=$key.'='.urlencode($val);
   }
   $param=join('&',$a);
   return $param;
}
function fanslist($page=0,$type=0){
   $api1='http://open.t.qq.com/api/friends/fanslist';
   $api2='https://open.t.qq.com/api/friends/idollist_s';
   if($type==0){//0粉丝
      $api=$api1;
   }else{
      $api=$api2;
   }
   
   $cans=array(
      'format'=>'json',//返回格式
	  'reqnum'=>10,//请求个数 1-30
	  'startindex'=>$page,//起始位置（第一页：填0，继续向下翻页：填上次请求返回的nextstartpos）
	  'mode'=>0,//获取模式，默认为0 mode=0，新粉丝在前，只能拉取1000个 mode=1，最多可拉取一万粉丝
	  //'install'=>0,//可选 安装本应用的好友 0忽略 1装 2没装
	  //'sex'=>0,//0忽略 1男 2女
   );
   $param=param($cans);
   $result=request($api.'?'.$param);
   return $result;
}
function tweet($content,$longitude=0,$latitude=0){//先经度后纬度
   $api='https://open.t.qq.com/api/t/add';

   $cans=array(
	  'content'=>$content,
      'format'=>'json'
   );
   if($longitude && $latitude){
      $cans1=array(
	     'longitude'=>$longitude,
	     'latitude'=>$latitude
	  );
	  $cans = array_merge($cans,$cans1);
   }
   $param=param($cans);
   return request($api.'?'.$param);
}
function timeline($pageflag=0,$pagetime=0,$reqnum=10,$type=0,$contenttype=0){
   $api='https://open.t.qq.com/api/statuses/home_timeline';
   $cans=array(
      'format'=>'json',
      'pageflag'=>$pageflag,//0：第一页，  向下翻页：1                   向上翻页：2
      'pagetime'=>$pagetime,//第一页：填0  向下翻页：最后一条记录时间    向上翻页：第一条记录时间
      'reqnum'=>$reqnum,//每次条数
	  'type'=>$type,//0x1 原创发表 0x2 转载 如需拉取多个类型请使用|，如(0x1|0x2)得到3，则type=3即可，0所有类型
	  'contenttype'=>$contenttype//内容过滤。0-表示所有类型，1-带文本，2-带链接，4-带图片，8-带视频，0x10-带音频 建议不使用contenttype为1的类型，如果要拉取只有文本的微博，建议使用0x80
   );
   $param=param($cans);
   return request($api.'?'.$param);
}
function tl_list($fanye=0){
   switch ($fanye) {
    case 1://向后
        $pageflag=1;
		$pagetime=$_SESSION['lasttime'];
        break;
    case -1://向前
        $pageflag=2;
		$pagetime=$_SESSION['firsttime'];
        break;
    default:
        $pageflag=0;
		$pagetime=0;
   }
   $host='http://t.qq.com/';
   $li='<ul>';
   $result = json_decode(timeline($pageflag,$pagetime),1);
   $result=$result['data'];
   $result=$result['info'];
   foreach($result as $t){
	  $img='';
      if($t['type']==1){
	     if($t['image'])$img='<br /><img src='.$t['image'][0].'/>';
         $tweet="<li><div id='t$t[id]' class='msgbox'><a href='$host$t[name]' class='nick'>$t[nick]</a>：
   	            $t[text]$img";
      }elseif($t['type']==2){
	     if($t['source']['image'])$img='<br /><img src='.$t['source']['image'][0].'/>';
         $tweet="<li><div id='t$t[id]' class='msgbox'><a href='$host$t[name]' class='nick'>$t[nick]</a>：$t[text]
		        <div class='msgbox'><a href='$host". $t['source']['name'] ."' class='nick'>".$t['source']['nick'].
				"</a>：".$t['source']['text']."$img<div class='pubinfo'><a target=_blank href=http://t.qq.com/p/t/".$t['source']['id']." class='zp'>转".$t['source']['count'].'评'.$t['source']['mcount']."</a></div></div>";
      }else continue;
      $li.=$tweet."<div class='pubinfo'><a target=_blank href=http://t.qq.com/p/t/".$t['id']." class='zp'>转$t[count]评$t[mcount]</a><span class='zhuanping'><a href=home.php?like=$t[id]>+1</a> <span onclick=zhuanping($t[id],0)>转播</span> <span onclick=zhuanping($t[id],1)>评论</span></span></div></div></li>";
	}
   $firsttime=$result[0]['timestamp'];
   $count=count($result);
   $lasttime=$result[$count-1]['timestamp'];
   $_SESSION['firsttime']=$firsttime;
   $_SESSION['lasttime']=$lasttime;
   return $li.'</ul>';
}
function retweet($content,$reid,$cz=0){//默认转播
   $api1='https://open.t.qq.com/api/t/re_add';//转播
   $api2='https://open.t.qq.com/api/t/comment';//评论
   if($cz==1)$api=$api2;//如果$cz==1评论
   else $api=$api1;//     否则转播
   $cans=array(
	  'content'=>$content,
      'format'=>'json',
	  'reid'=>$reid
   );
   $param=param($cans);
   $result=request($api.'?'.$param);
   $result=json_decode($result,1);
   if($result['errcode']==0) return true;
   else return false;
}
function at($pageflag=0,$pagetime=0,$reqnum=10,$type=0,$contenttype=0,$lastid=0){
   $api='https://open.t.qq.com/api/statuses/mentions_timeline';
   $cans=array(
      'format'=>'json',
      'pageflag'=>$pageflag,//0：第一页，  向下翻页：1                   向上翻页：2
      'pagetime'=>$pagetime,//第一页：填0  向下翻页：最后一条记录时间    向上翻页：第一条记录时间
      'reqnum'=>$reqnum,//每次条数
	  'type'=>$type,//0x1 原创发表 0x2 转载 如需拉取多个类型请使用|，如(0x1|0x2)得到3，则type=3即可，0所有类型
	  'contenttype'=>$contenttype,//内容过滤。0-表示所有类型，1-带文本，2-带链接，4-带图片，8-带视频，0x10-带音频 建议不使用contenttype为1的类型，如果要拉取只有文本的微博，建议使用0x80
	  'lastid'=>$lastid
   );
   $param=param($cans);
   return request($api.'?'.$param);
}
function at_list($fanye=0){
   switch ($fanye) {
    case 1://向后
        $pageflag=1;
		$pagetime=$_SESSION['at_lasttime'];
		$lastid=$_SESSION['at_lid'];
        break;
    case -1://向前
        $pageflag=2;
		$pagetime=$_SESSION['at_firsttime'];
		$lastid=$_SESSION['at_fid'];
        break;
    default:
        $pageflag=0;
		$pagetime=0;
		$lastid=0;
   }
   $host='http://t.qq.com/';
   $li='<ul>';
   $result = json_decode(at($pageflag,$pagetime,$lastid),1);
   $result=$result['data'];
   $result=$result['info'];
   foreach($result as $t){
	  $img='';
      if($t['type']==1){
	     if($t['image'])$img='<br /><img src='.$t['image'][0].'/>';
         $tweet="<li><div id='t$t[id]' class='msgbox'><a href='$host$t[name]' class='nick'>$t[nick]</a>：
   	            $t[text]$img";
      }elseif($t['type']==2){
	     if($t['source']['image'])$img='<br /><img src='.$t['source']['image'][0].'/>';
         $tweet="<li><div id='t$t[id]' class='msgbox'><a href='$host$t[name]' class='nick'>$t[nick]</a>：$t[text]
		        <div class='msgbox'><a href='$host". $t['source']['name'] ."' class='nick'>".$t['source']['nick'].
				"</a>：".$t['source']['text']."$img<div class='pubinfo'><a target=_blank href=http://t.qq.com/p/t/".$t['source']['id']." class='zp'>转".$t['source']['count'].'评'.$t['source']['mcount']."</a></div></div>";
      }else continue;
      $li.=$tweet."<div class='pubinfo'><a target=_blank href=http://t.qq.com/p/t/".$t['id']." class='zp'>转$t[count]评$t[count]</a><span class='zhuanping'><a href=home.php?like=$t[id]>+1</a> <span onclick=zhuanping($t[id],0)>转播</span> <span onclick=zhuanping($t[id],1)>评论</span></span></div></div></li>";
	}
   $count=count($result);
   $firsttime=$result[0]['timestamp'];
   $fid=$result[0]['id'];
   $lid=$result[$count-1]['id'];
   $lasttime=$result[$count-1]['timestamp'];
   $_SESSION['at_firsttime']=$firsttime;
   $_SESSION['at_lasttime']=$lasttime;
   $_SESSION['at_fid']=$fid;
   $_SESSION['at_lid']=$lid;
   return $li.'</ul>';
}
function updata($type='',$op=0){
   $api='https://open.t.qq.com/api/info/update';
   $cans=array(
      'format'=>'json',
	  'op'=>$op,//0：仅获取数据更新的条数；1：获取完毕后将相应的计数清零。
	  'type'=>$type
   );//type 5：首页未读消息计数；
     //           6：@页未读消息计数；
     //           7：私信页未读消息计数；
     //           8：新增听众数；
     //           9：首页新增的原创广播数。
     //           op=0时不输人type，返回所有类型计数；
     //           op=1时需输入type，返回所有类型计数，同时清除该type类型的计数。
   
   $param=param($cans);
   $result=request($api.'?'.$param);
   $result=json_decode($result,1);
   if($result['ret']!=0) return false;
   return $result;
}

function info(){
   $api='https://open.t.qq.com/api/user/info';
   $cans=array(
      'format'=>'json'
   );
   $param=param($cans);
   $result=request($api.'?'.$param);
   $data=json_decode($result,true);
   $data=$data['data'];
   $_SESSION['nick']=$data['nick'];
   $_SESSION['name']=$data['name'];
   return $data;
}
function refresh_token($access_token,$refresh_token){
   global $appid;
   $cans=array(
      'client_id'=>$appid,
	  'grant_type'=>'refresh_token',
	  'refresh_token'=>$refresh_token
   );
   foreach($cans as $key=>$val){
      $a[].=$key.'='.$val;
   }
   $param=join('&',$a);
   $api='https://open.t.qq.com/cgi-bin/oauth2/access_token';
   $result=request($api.'?'.$param);
   $result=explode('&',$result);
   foreach($result as $val){
      $r=explode('=',$val);
      $k[].=$r[0];
      $v[].=$r[1];
   }
   $info=array_combine($k,$v);
   $_SESSION['access_token']=$info['access_token'];
   $_SESSION['refresh_token']=$info['refresh_token'];
   print_r(info());
}
?>