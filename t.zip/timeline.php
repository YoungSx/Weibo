﻿<?php
include('lib.php');
$access_token=$_SESSION['access_token'];

if(!isset($_SESSION['access_token'])) exit;

$result = json_decode(timeline(1,1367244838),1);
print_r($result);




?>