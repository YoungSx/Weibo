﻿<html>
 <head>
  <meta name="viewport" content="width=371, initial-scale=1.0, maximum-scale=2.0, user-scalable=yes"/>
  <title>Ysx版微博</title>
  <style>
   html,body{
    margin:0px;
	background:#128ABC;
   }
   #main{
    width: 371px;
    margin: 0px auto;
	color:white;
	text-shadow:3px 3px 5px black;
   }
   a{
	color:white;
	text-decoration:none;
   }
   #title{
    width:110px;
	margin:0px auto;
	font-size:24px;
	color:orange;
   }
   #login{
    float:right;
    width:135px;
	padding:5px;
	margin:10px;
	background:#1ABDE6;
	border:2px #1169EE solid;
	border-radius:5px;
    cursor:pointer;
	text-shadow:0px 0px 5px black;
   }
   #login:hover{
    box-shadow:0px 0px 5px pink;
   }
   #login:active{
    box-shadow:0px 0px 5px red;
   }
   #des{
    text-indent:2em;
	margin:5px;
	text-shadow:1px 1px 5px black;
   }
  </style>
 </head>
 <body>
  <div id="main">
   <img src="t.gif"/>
   <div id="title">Ysx版微博</div>
   <div id="des">一个第三方腾讯微博，基于腾讯微博开放API。相同的内容，不同的体验！<br />最新增加了重力操纵，手机稍倾斜就可滚动页面。点击右下角的按钮开始授权。</div>
   <div id="login"><a href="home.php">腾讯微博帐号登陆</a></div>
  </div>
 </body>
</html>