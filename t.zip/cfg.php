﻿<?php
$appid='c83601b2fd6449639f7388d820c0e1f9';
$callback='http://www.huise.tk/callback.php';
$appkey='c16260962b0d69ceeb0994a5b582ddca';