﻿function zhuanping(id,cz){
   box=document.getElementById('t'+id);
   if(!open){
      open=true;
      old=box.innerHTML;
      switch(cz)
      {
      case 0:
       botton='转播'; 
       break;
      case 1:
       botton='评论'; 
       break;
      default:
       botton='发表'; 
      }
      box.innerHTML+=
      "<div class='zpbox'><form action='index.php' method='post'>"+
      "<textarea name='zpcont'></textarea>"+
	  "<input type='hidden' name='cz' value='"+cz+"'/><input type='hidden' name='id' value='"+id+"'/><div class='bar'><input type='submit' value='"+botton+"'/>"
      +"</div></form></div>";
   }else{
      open=false;
	  box.innerHTML=old;
   }
}
function yc(id){
   box=document.getElementById(id);//box.style.display='none'
   setTimeout("box.style.display='none'",2000);
}
if(navigator.geolocation){
   //alert('支持定位！');
   //navigator.geolocation.getCurrentPosition(info,cuowu);
}else{
   //alert('不支持定位！');
}
function info(position){
   a=document.getElementById('longitude');
   b=document.getElementById('latitude');
   c=document.getElementById('local');
   a.value=position.coords.longitude;
   b.value=position.coords.latitude;
   c.value='已定位';
   c.style.background='orange';
}
function cuowu(){

}
body=document.getElementsByTagName("body");
body=body[0];
body.style.width=window.screen.width-20px;