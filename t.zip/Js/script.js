﻿var old,boxOpen;
window.addEventListener('deviceorientation', update, true);
var lastTime=0,v=0,last=1;
function update(event){
   var interval=30;//间隔时间
   var deg=event.beta-20;
   var beta=Math.round(deg-20)*3.14/180;
   var a=Math.sin(beta)*9.82*15;//用倾斜角度求加速度(*10因为加速度太小)
   if(((last>0) && (a<0) ) || ((last<0) && (a>0))) v=0;
   last=a;
   v=v+a*(interval/1000);//用加速度求速度（不确定对）
   var curTime = new Date().getTime();
   if( (curTime-lastTime>interval) && ( (deg<-0) || (deg>15))  ){//留出静止的一定角度以便用户进行操作。
      if(document.body.scrollTop>=0 || beta>=0) scroll(0,document.body.scrollTop+v+deg);
   }
   lastTime=curTime;
}
function zhuanping(id,cz){
   box=document.getElementById('t'+id);
   if(!boxOpen){
      boxOpen=true;
      old=box.innerHTML;
      switch(cz)
      {
      case 0:
       botton='转播';
       break;
      case 1:
       botton='评论';
       break;
      default:
       botton='发表';
      }
      box.innerHTML+=
      "<div class='zpbox'><form action='home.php' method='post'>"+
      "<textarea name='zpcont' style='width:100%;'></textarea>"+
	  "<input type='hidden' name='cz' value='"+cz+"'/><input type='hidden' name='id' value='"+id+"'/><div class='bar'><input type='submit' value='"+botton+"'/>"
      +"</div></form></div>";
   }else{
      boxOpen=false;
	  box.innerHTML=old;
   }
}
function yc(id){
   box=document.getElementById(id);//box.style.display='none'
   if(box) setTimeout("box.style.display='none'",2000);
}
if(navigator.geolocation){
   //alert('支持定位！');
   //navigator.geolocation.getCurrentPosition(info,cuowu);
}else{
   //alert('不支持定位！');
}
function info(position){
   a=document.getElementById('longitude');
   b=document.getElementById('latitude');
   c=document.getElementById('local');
   a.value=position.coords.longitude;
   b.value=position.coords.latitude;
   c.value='已定位';
   c.style.background='orange';
}
function cuowu(){

}